# CSI4999-ImageClassification

IMPORTANT: CREATE A VENV ENVIRONMENT WITH numpy==1.23.5 streamlit==1.22.0 Pillow==9.5.0 keras==2.12.0 tensorflow==2.12.0 BEFORE YOU DO ANYTHING

check https://docs.python.org/3/library/venv.html for more information

initenv.sh or initenv.ps1 will do this for you.

Once the environment is created, run 

$ source environment/bin/activate (bash)

or

PS> environment/Scripts/Activate.ps1 (PowerShell)

to activate it
