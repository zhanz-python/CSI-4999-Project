python3 -m venv environment
source environment/bin/activate
pip install numpy streamlit==1.22.0 Pillow keras tensorflow sqlite3
