python3.11 -m venv environment
environment\Scripts\Activate.ps1
pip install numpy streamlit==1.22.0 Pillow keras tensorflow sqlite3
